#from django.shortcuts import render,redirect

from django.http import HttpResponse
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.shortcuts import render, redirect
from django.contrib import messages

from main.models import User,TheifLocation, Person,Record 

from django.contrib.auth import logout


#from datetime import datetime
import face_recognition
from PIL import Image, ImageDraw
import numpy as np
import cv2

#from django.views.generic import View
from .utils import render_to_pdf #created in step 4 


from imutils.video import WebcamVideoStream
from imutils.video import FileVideoStream
from imutils.video import FPS
#import numpy as np

import imutils
import time




global a,b
a=0
b=0

'''
from rest_framework.views import APIView
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.response import Response
from rest_framework import status
from .serializers import FileSerializer


class FileView(APIView):
  parser_classes = (MultiPartParser, FormParser)
  def post(self, request, *args, **kwargs):
    file_serializer = FileSerializer(data=request.data)
    if file_serializer.is_valid():
      file_serializer.save()
      return Response(file_serializer.data, status=status.HTTP_201_CREATED)
    else:
      return Response(file_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

'''


def index(request):
    #print(1)
    return render(request,'login.html')

def login(request):
    #print(1)
    #if request.method:
    #   return HttpResponse("success")
    
    if (User.objects.filter(email=request.POST['login_email']).exists() and User.objects.filter(password=request.POST['login_password']).exists()  ):
        user = User.objects.filter(email=request.POST['login_email'])[0]
        #print(User.objects.filter(email=request.POST['login_email']))
        request.session['id'] = user.id
        request.session['name']=user.first_name
        request.session['surname'] = user.last_name
        messages.add_message(request,messages.INFO,'Welcome'+user.first_name)
        return redirect(success)
    else:
        
        messages.error(request,'wrong person')
        return redirect('/')
    
def success(request):
    user = User.objects.get(id=request.session['id'])
    context ={
            "user":user}
    return render(request,'welcome.html',context)



def logout_view(request):
    logout(request)
    messages.add_message(request,messages.INFO,"LOGDED OFF")
    return redirect(index)


def addUser(request):
    return render(request,'add_users.html')

def viewUser(request):
    users = User.objects.all()
    context = {
            "users":users}
    return render(request,'view_users.html',context)


def saveUser(request):
    errors = User.objects.validator(request.POST)
    if len(errors):
        for tag,error in errors.items():
            messages.error(request,error,extra_tags=tag)
        return redirect (addUser)
    
    user = User.objects.create(
        first_name=request.POST['first_name'],
        last_name=request.POST['last_name'],
        email=request.POST['email'],
        password=request.POST['password'])
    user.save()
    messages.add_message(request,messages.INFO , 'ADDED')
    return redirect(viewUser)    


def addCriminal(request):
    return render(request,'add_criminals.html')

def saveCriminal(request):
    
    if request.method == 'POST':
        criminal = Person.objects.filter(national_id=request.POST["national_id"])
        
        if criminal.exists():
            messages.error(request,"Criminal ID exits")
            return redirect(addCrime)
        else:
            myfile = request.FILES['image']
            fs = FileSystemStorage()
            filename = fs.save(myfile.name, myfile)
            uploaded_file_url = fs.url(filename)
            
            print(fs)
            
            x=settings.MEDIA_ROOT
            
            #here
            print(x)
            y = str(x) +str(uploaded_file_url)
            y = y.replace('/media/','\\')
            print(y)
            #image = face_recognition.load_image_file("C:\\Users\\pothi\\Desktop\\copy\\C\\" +uploaded_file_url)
            image = face_recognition.load_image_file(y)
            
            
            #image = face_recognition.load_image_file("C:\\Users\\pothi\\Desktop\\try\\police\\" +uploaded_file_url)
            #face_encoding = face_recognition.face_encodings(image)[0]
            
            try:
                face_encoding = face_recognition.face_encodings(image)[0]
            except:
                messages.error(request,"PHOTO is not SUITABLE PLEASE CHANGE!!!")
                #print(0)
                return redirect(addCriminal)
            
            
            face_encoding=[str(i) for i in face_encoding]   # to string 
            x = '_'.join(face_encoding)
            
            
            
            person = Person.objects.create(
                    name = request.POST['name'].title(),
                    national_id = request.POST['national_id'],
                    address = request.POST['address'].title(),
                    picture = uploaded_file_url[1:],
                    status = 'Free',
                    face = x
                    
                    )
            person.save()
            
            record = Record.objects.create(
                    national_id = request.POST["national_id"],
                    crime = request.POST["crime"].title(),
                    place = request.POST["place"].title(),
                    date = request.POST["date"]
                    )
            record.save()
            
            messages.add_message(request, messages.INFO, "Citizen successfully added")
            return redirect(viewCriminal)




def viewCriminal(request):
    
    criminals = Person.objects.all()
    context={
            "criminals":criminals
            }
    return render(request,"view_criminals.html",context)



def addCrime(request):
    return render(request,'add_crimes.html')

def saveCrime(request):
    if request.method=='POST':
        criminal = Person.objects.filter(national_id=request.POST["national_id"])
        if not criminal.exists():
            messages.error(request,"crime ID not registerded")
            return redirect(addCrime)
        
        criminal=Record.objects.filter(national_id=request.POST["national_id"]).filter(crime=request.POST["crime"])
        
        if criminal.exists():
            messages.error(request,"criminal crime exixst")
            return redirect(addCrime)
        else:
            record = Record.objects.create(
                    national_id =request.POST["national_id"],
                    crime = request.POST["crime"].title(),
                    place = request.POST["place"].title(),
                    date = request.POST["date"]
                    )
            record.save()
            messages.add_message(request, messages.INFO, str(request.POST["national_id"])+" Crime successfully added")
            return redirect(addCrime)
        
def viewRecord(request,criminal_id):
    crimes = Record.objects.filter(national_id=criminal_id)
    context ={
            "crimes":crimes,
            "c_id":criminal_id,
            }
    return render(request,"view_records.html",context)



def detectImage(request):
    # This is an example of running face recognition on a single image
    # and drawing a box around each person that was identified.

    # Load a sample picture and learn how to recognize it.

    #upload image
    
    
    if request.method == 'POST' and request.FILES['image']:
        myfile = request.FILES['image']
        fs = FileSystemStorage()
        print(fs)
        filename = fs.save(myfile.name, myfile)
        uploaded_file_url = fs.url(filename)
        
        
    #print(person)
    print(uploaded_file_url)
    x1=''
    #x1="C:\\Users\\pothi\\Desktop\\copy\\C\\" 
    images=[]
    encodings=[]
    names=[]
    files=[]
    
    prsn=Person.objects.all()
    
    
    for crime in prsn:
        images.append(crime.name+'_image')
        x = crime.face.split('_')
        l = [float(j) for j in x]
        encodings.append(l)
        files.append(crime.picture)
        names.append(crime.name)
    
    known_face_encodings = encodings
    known_face_names = names
    
    unknown_image = face_recognition.load_image_file(x1+str(uploaded_file_url[1:]))
    
    face_locations = face_recognition.face_locations(unknown_image)
    face_encodings = face_recognition.face_encodings(unknown_image, face_locations)

    pil_image = Image.fromarray(unknown_image)
    
    draw = ImageDraw.Draw(pil_image)

    # Loop through each face found in the unknown image
    for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
        # See if the face is a match for the known face(s)
        matches = face_recognition.compare_faces(known_face_encodings, face_encoding, tolerance=0.50)

        Name = "Unknown"
        face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
        best_match_index = np.argmin(face_distances)
        color = "green"
        
        if matches[best_match_index]:
            Name = known_face_names[best_match_index]
            
            criminal = Person.objects.filter(name=Name)[0]    #here
            if criminal.status == "Wanted":
                color = "red"
                
                track = TheifLocation.objects.create(
                        name = criminal.name,
                        national_id = criminal.national_id,
                        address = criminal.address,
                        picture = criminal.picture,
                        status = criminal.status,
                        latitude = a,
                        longitude = b,
                        
                        )
                track.save()
            else:                               # if not WANTED  and already in crimianl DB   shows blue box
                    color = "blue" 
                    
            

        # Draw a box around the face using the Pillow module
        draw.rectangle(((left, top), (right, bottom)), outline=color)

        # Draw a label with a name below the face
        text_width, text_height = draw.textsize(Name)
        draw.rectangle(((left, bottom - text_height - 10), (right, bottom)), fill=color, outline=color)
        draw.text((left + 6, bottom - text_height - 5), Name, fill=(255, 255, 255, 255))

    # Remove the drawing library from memory as per the Pillow docs
    del draw

    # Display the resulting image
    pil_image.show()
    return redirect('/success')







def detectWithWebcam(request):
    # Get a reference to webcam #0 (the default one)
    #d={}
    
    
    #video_capture = cv2.VideoCapture(0)
    
    vs = WebcamVideoStream(0).start()

    #fps = FPS().start()
    time.sleep(1.0)
    
    
    # Load a sample picture and learn how to recognize it.
    images=[]
    encodings=[]
    names=[]
    files=[]
    nationalIds=[]

    prsn=Person.objects.all()
    
    
    for crime in prsn:
        images.append(crime.name+'_image')
        x = crime.face.split('_')
        l = [float(j) for j in x]
        encodings.append(l)
        files.append(crime.picture)
        #names.append(crime.name)
        names.append('Name: '+crime.name)# + ', National ID: '+ crime.national_id ', Address '+crime.address
        nationalIds.append(crime.national_id)
    
    
    # Create arrays of known face encodings and their names
    #print(encodings)
    
    known_face_encodings = encodings
    known_face_names = names
    #n_id=nationalIds

    while True:
        
        try:
            # Grab a single frame of video
            frame = vs.read()
            #print(ret,frame)
            # Convert the image from BGR color (which OpenCV uses) to RGB color (which face_recognition uses)
            rgb_frame = frame[:, :, ::-1]
        
            # Find all the faces in the current frame of video
            face_locations = face_recognition.face_locations(rgb_frame)
            face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)
            # Display the results
            
            
            for (top, right, bottom, left),face_encoding in zip(face_locations,face_encodings):
                # Draw a box around the face
                matches = face_recognition.compare_faces( known_face_encodings , face_encoding, tolerance=0.50)
                Name = 'Unkown'
                
                face_distances = face_recognition.face_distance( known_face_encodings , face_encoding)
                best_match_index = np.argmin(face_distances)
                
                color = (0,255,0)
                if matches[best_match_index]:
                    Name =   known_face_names[best_match_index]
    
                    criminal = Person.objects.filter(name=Name[6:])[0]   # to get name only
                    if criminal.status == "Wanted":           # if wanted  shows red box  and stores details in theifLocation table  to track
                        
                        color = (0,0,255)
                        
                        track = TheifLocation.objects.create(
                                name = criminal.name,
                                national_id = criminal.national_id,
                                address = criminal.address,
                                picture = criminal.picture,
                                status = criminal.status,
                                latitude = a,
                                longitude = b,
                                
                                )
                        track.save()
                    else:                               # if not WANTED  and already in crimianl DB   shows blue box
                        color = (255,0,0) 
    
                cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
                
                cv2.rectangle(frame, (left, bottom - 25), (right, bottom), color, cv2.FILLED)
                font = cv2.FONT_HERSHEY_DUPLEX
                cv2.putText(frame, Name, (left + 6, bottom - 6), font, 0.5, (255, 255, 255), 1)
                
    
    
    
            # Display the resulting image
            cv2.imshow('Video', frame)
    
            # Hit 'q' on the keyboard to quit!
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        except:
            print("ERROR")
            break



    vs.stop()
    cv2.destroyAllWindows()
    return redirect('/success')







#here



def detectInVideo(request):
    
    if request.method == 'POST' and request.FILES['video']:
        myfile = request.FILES['video']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        uploaded_file_url = fs.url(filename)
    print(1)
    
    x=settings.MEDIA_URL
    y = str(x)+str(uploaded_file_url)
    y = y[8:]
    print(y)
    
    #video_capture = cv2.VideoCapture(y)
    fvs = FileVideoStream(y).start()
    fps = FPS().start()


    time.sleep(1.0)
    
    
    images=[]
    encodings=[]
    names=[]
    files=[]
    nationalIds=[]

    prsn=Person.objects.all()
    
    for crime in prsn:
        images.append(crime.name+'_image')
        x = crime.face.split('_')
        l = [float(j) for j in x]
        encodings.append(l)
        files.append(crime.picture)
        names.append(crime.name)
        #names.append('Name: '+crime.name)# + ', National ID: '+ crime.national_id ', Address '+crime.address
        nationalIds.append(crime.national_id)
    print(2)
    for i in range(0,len(images)):
        images[i]=face_recognition.load_image_file(files[i])
        encodings[i]=face_recognition.face_encodings(images[i])[0]

    # Create arrays of known face encodings and their names
    #print(encodings)
    known_face_encodings = encodings
    known_face_names = names
    #n_id=nationalIds
  
    
    while fvs.more():
        # Grab a single frame of video
        try:
            frame = fvs.read()
            frame = imutils.resize(frame, width=950)     # less width more fast less accuracy 
            #print(ret,frame)
            # Convert the image from BGR color (which OpenCV uses) to RGB color (which face_recognition uses)
            rgb_frame = frame[:, :, ::-1]
        
            # Find all the faces in the current frame of video
            face_locations = face_recognition.face_locations(rgb_frame)
            face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)
            # Display the results
            
            
            for (top, right, bottom, left),face_encoding in zip(face_locations,face_encodings):
                # Draw a box around the face
                matches = face_recognition.compare_faces( known_face_encodings , face_encoding, tolerance=0.50)
                Name = 'Unkown'
                
                face_distances = face_recognition.face_distance( known_face_encodings , face_encoding)
                best_match_index = np.argmin(face_distances)
                
                
                color = (0,255,0)
                if matches[best_match_index]:
                    Name =   known_face_names[best_match_index]
                    #color = (0,0,255)
                    criminal = Person.objects.filter(name=Name)[0]
                    if criminal.status == "Wanted":
                        color = (0,0,255)
                        
                        track = TheifLocation.objects.create(
                                name = criminal.name,
                                national_id = criminal.national_id,
                                address = criminal.address,
                                picture = criminal.picture,
                                status = criminal.status,
                                latitude = a,
                                longitude = b,
                                
                                )
                        track.save()
                    else:                               # if not WANTED  and already in crimianl DB   shows blue box
                        color = (255,0,0) 
 
                cv2.rectangle(frame, (left, top), (right, bottom), color)
                
                cv2.rectangle(frame, (left, bottom - 25), (right, bottom), color, cv2.FILLED)
                font = cv2.FONT_HERSHEY_DUPLEX
                cv2.putText(frame, Name, (left + 6, bottom - 6), font, 0.5, (255, 255, 255), 1)
        
            # Display the resulting image
            cv2.imshow('VIDEO', frame)
        
            # Hit 'q' on the keyboard to quit!
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
            fps.update()
        
        except:
            print("error")
            break

    # Release handle to the webcam
    fvs.stop()
    fps.stop()
    cv2.destroyAllWindows()
    
    
    return redirect('/success')





def wantedCriminal(request, criminal_id):
    wanted = Person.objects.filter(pk=criminal_id).update(status='Wanted')
    if (wanted):
        messages.add_message(request,messages.INFO,"User successfully changed status to wanted")
    else:
        messages.error(request,"Failed to change the status of the criminal")
    return redirect(viewCriminal)



def freeCriminal(request, criminal_id):
    free = Person.objects.filter(pk=criminal_id).update(status='Free')
    if (free):
        messages.add_message(request,messages.INFO,"User successfully changed status to Found and Free from Search")
    else:
        messages.error(request,"Failed to change the status of the criminal")
    return redirect(viewCriminal)



def spottedCriminals(request):
    thiefs=TheifLocation.objects.filter(status="Wanted")
    context={
        'thiefs':thiefs
    }
   
    return render(request,'spotted_thiefs.html',context)



def foundThief(request,theif_id):
    free = TheifLocation.objects.filter(pk=theif_id)
    freectzn = TheifLocation.objects.filter(national_id=free.get().national_id).update(status='Found')
    print(free , freectzn)
    if(freectzn):
        theif = TheifLocation.objects.filter(pk=theif_id)
        free = Person.objects.filter(national_id=theif.get().national_id).update(status='Found')
        if(free):
            messages.add_message(request,messages.INFO,"Thief updated to found, congratulations")
        else:
            messages.error(request,"Failed to update thief status")
    return redirect(spottedCriminals)



def viewTheifLocation(request,theif_id):
    
    thiefs = TheifLocation.objects.filter(pk=theif_id)
    context={
        "thiefs":thiefs
    }
    #return render(request,'https://www.google.com/maps/@'+str(a)+','+str(b)+'17.56z',context)
    #return redirect (spottedCriminals)
    return render(request,'loc.html',context)
	
 
def viewReports(request):
    labels = ["wanted","free","found"]
    data = [0,0,0]

    for i in labels:
        queryset = Person.objects.filter(status=i)
        for j in queryset:
            data[labels.index(i)]+=1


    return render(request, 'reports.html', {
        'labels': labels,
        'data': data,
    })
    
    #return render(request,"reports.html")

 
def viewProfile(request,criminal_id):
    crim = Person.objects.filter(national_id=criminal_id)
    context ={
            'crim':crim
            }
    return render(request,'profile.html',context)


def pdf_view(request,criminal_id):
    crim = Person.objects.filter(national_id=criminal_id)
    #template = get_template('profile.html')
    x=crim[0]
    y=str(x.picture)
    y=settings.MEDIA_ROOT+'\\'+y[6:]
    data = {
            'crim':crim,
            'pic':y,
    }
    
    
    
    #pdf = render_to_pdf('profile_data.html', data)
    #return HttpResponse(pdf, content_type='application/pdf')

    #html = template.render(context)
    pdf = render_to_pdf('profile_data.html', data)
    if pdf:
        response = HttpResponse(pdf, content_type='application/pdf')
        filename = "Criminal_%s.pdf" %(str(criminal_id))
        content = "inline; filename='%s'" %(filename)
        download = request.GET.get("download")
        print(1)
        if download:
            content = "attachment; filename='%s'" %(filename)
            print(2)
        response['Content-Disposition'] = content
        return response
    return HttpResponse("Not found")


'''
#from django.http import HttpResponse
from django.template.loader import render_to_string

#from django.template import RequestContext
#from django.conf import settings
import ho.pisa as pisa
import cStringIO as StringIO
import cgi
import os

def pdf(request,criminal_id):
    crim = Person.objects.filter(national_id=criminal_id)
    #template = get_template('profile.html')
    data = {
            'crim':crim
    }
    html  = render_to_string('profile.html', { 'pagesize' : 'A4', }, context_instance=data)
    #template = get_template('profile.html')
    
    result = StringIO.StringIO()
    pdf = pisa.pisaDocument(StringIO.StringIO(html.encode("UTF-8")), dest=result, link_callback=fetch_resources )
    if not pdf.err:
        return HttpResponse(result.getvalue(), mimetype='application/pdf')
    return HttpResponse(' your pdf! %s' % cgi.escape(html))


def fetch_resources(uri, rel):
    path = os.path.join(settings.MEDIA_ROOT, uri.replace(settings.MEDIA_URL, ""))

    return path



'''
#from fpdf import FPDF

# imagelist is the list with all image filenames
'''

def pdf_view(request,criminal_id):
    crim = Person.objects.filter(national_id=criminal_id)
    #template = get_template('profile.html')
    data = {
            'crim':crim
    }
    x=crim[0]
    pdf = FPDF()
    pdf.add_page()
    y=str(x.picture)
    y=y[6:]
    pdf.image(settings.MEDIA_ROOT+'\\'+y ,350,100,20,15)
    p=pdf.output("yourfile.pdf", "F")
    
    #pdf = render_to_pdf('profile.html', data)
    return HttpResponse(p, content_type='application/pdf')
'''