from django.urls import path,include
from django.conf.urls import url
from django.conf import settings

from django.conf.urls.static import static
#from main.views import FileView



from . import views

urlpatterns = [
        url(r'^$', views.index),
        url(r'^login$', views.login),
        url(r'^success$',views.success),
        url(r'^logout$',views.logout_view),
        
        url(r'^add_users$',views.addUser),
        url(r'^save_users$',views.saveUser),
        url(r'^view_users$',views.viewUser),
        
        url(r'^add_criminals$',views.addCriminal),
        url(r'^view_criminals$',views.viewCriminal),
        url(r'^save_criminals$',views.saveCriminal),
        
        path('wanted_criminal/<int:criminal_id>/',views.wantedCriminal,name='wanted_criminal'),
        path('free_criminal/<int:criminal_id>/',views.freeCriminal,name='free_criminal'),
        
        url(r'^add_crimes$',views.addCrime),
        url(r'^save_crimes$',views.saveCrime),
        url(r'^view_records/(\d+)/',views.viewRecord,name='criminal_id'),
        
        url(r'^detectImage$',views.detectImage),
        url(r'^detectInVideo$',views.detectInVideo),
        url(r'^detectWithWebcam$',views.detectWithWebcam),
        
        
        url(r'^spotted_criminals$',views.spottedCriminals),
        path('theif_location/<int:theif_id>/',views.viewTheifLocation,name='theif_location'),
        path('found_theif/<int:theif_id>/', views.foundThief, name='found_theif'),
        
        url(r'^reports', views.viewReports),
        url(r'^profile_view/(\d+)/',views.viewProfile,name='criminal_id'),
        url(r'^pdf/(\d+)/',views.pdf_view,name='criminal_id'),
        
        
        ]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
