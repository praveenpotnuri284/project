from django.db import models

# Create your models here.


class UserManager(models.Manager):
    def validator(self,postData):
        for i in postData:
            print(postData[i])
        errors = {}
        if not  (postData['first_name'].isalpha()):
            if len(postData['first_name'])<2:
                errors['first_name'] = "First name is short"
        if (postData['last_name'].isalpha()) == False:
            if len(postData['last_name']) < 2:
                errors['last_name'] = "Last name can not be shorter than 2 characters"

        if len(postData['email']) == 0:
            errors['email'] = "email error"
        
        if len(postData['password'])<8:
            errors['password'] = "pass is short"
        return errors

class User(models.Model):
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    email = models.CharField(max_length=255,default=None)
    password = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)
    objects = UserManager()
    
class TheifLocation(models.Model):
    name = models.CharField(max_length=255)
    national_id = models.CharField(max_length=255)
    address = models.CharField(max_length=255)
    picture = models.CharField(max_length=255)
    status = models.CharField(max_length=255)
    latitude = models.CharField(max_length=255)
    longitude = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    
class  Person(models.Model):
    name = models.CharField(max_length=255)
    national_id = models.CharField(max_length=255,default=None)
    address = models.CharField(max_length=255)
    picture = models.CharField(max_length=255)
    status = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    face = models.CharField(max_length=5000,default=None) 
 

class Record(models.Model):
    national_id = models.CharField(max_length=20)
    crime = models.CharField(max_length=30)
    place = models.CharField(max_length=50)
    date = models.DateField()

''' 
class File(models.Model):
  file = models.FileField(blank=False, null=False)
  remark = models.CharField(max_length=20)
  timestamp = models.DateTimeField(auto_now_add=True) 
'''