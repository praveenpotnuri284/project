import geocoder
g = geocoder.ip('117.208.136.10')
print(g.geojson['features'][-1]['geometry']['coordinates'])