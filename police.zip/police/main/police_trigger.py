import requests
#import folium
#from IPython.display import  HTML,display
res=requests.get("https://ipinfo.io/")
data =res.json()
#print(data)

data=data['loc'].split(',')
latt=data[0]
long=data[1]
police_list=[]
url=["https://maps.googleapis.com/maps/api/place/search/json?location=","&radius=10000&types=police&sensor=true&key="]
key="AIzaSyDxgXF-_8jkF2layaFwRdSkYTHqClr6XDw"
loc=latt+','+long
url1=url[0]+loc+url[1]+key
res1=requests.get(url1)
data1=res1.json()
print(data1)
data1=data1['results']
print(data1)
#for item in data1:
  #  police_list.append(item['name'])

