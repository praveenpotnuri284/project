#not needed


c='b'
s='abcd'

x=s.split(c)

t=0
p
for i in x:
    l=len(i)
    t+=l*(l+1)/2
print(t)